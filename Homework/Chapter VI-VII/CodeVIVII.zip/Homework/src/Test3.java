public class Test3 {

    /**
     * 创建一个不规则二维数组
     * @param row 行数
     * @return 创建好的不规则数组
     */
    public static int[][] createArray(int row) {
        if (row <= 0) {
            return null;
        }

        int[][] array = new int[row][];

        for (int i = 0; i < row; i++) {
            array[i] = new int[row - i];
        }

        return array;
    }

    /**
     * 逐行打印出二维数组，数组元素之间以空格分开
     * @param a 传入的二维数组
     */
    public static void printArray(int[][] a) {
        if (a == null) {
            return; // 容错处理
        }
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        int rows = 5;
        int[][] myArray = createArray(rows);
        printArray(myArray);

        int[][] invalidArray = createArray(-2);
        printArray(invalidArray);
    }
}